import os
os.system('')
from colorama import Fore, Back, Style

os.system('title LoshV0.1 [https://github.com/loshprogramer/losh]')

import sys
import traceback

import chat_downloader
from datetime import datetime, timedelta, date
import pytchat

import requests
import urllib3
urllib3.disable_warnings()

import emoji
import ctypes
import time

import threading

#================================================BOJE POZADINA
crvena = Fore.WHITE + Style.BRIGHT + Back.RED
zuta = Fore.WHITE + Style.BRIGHT + Back.YELLOW
zelena = Fore.WHITE + Style.BRIGHT + Back.GREEN
plava = Fore.WHITE + Style.BRIGHT + Back.BLUE
bela = Fore.BLACK + Style.DIM + Back.WHITE  
normalna = Fore.WHITE + Style.BRIGHT + Back.BLACK
resetuj = Style.RESET_ALL
#================================================ BOJE TEXT
crvena2 = Fore.RED + Style.BRIGHT + Back.BLACK
zuta2 = Fore.YELLOW + Style.BRIGHT + Back.BLACK
plava2 = Fore.BLUE + Style.BRIGHT + Back.BLACK
zelena2 = Fore.GREEN + Style.BRIGHT + Back.BLACK
#================================================

def blinkaj():
    ctypes.windll.user32.FlashWindow(ctypes.windll.kernel32.GetConsoleWindow(), True )

def internetprovera():
	# sa stackoverflow resenje brze nego python requests
    return os.system('ping www.google.com -n 1 -w 1000 > nul & if errorlevel 1 (exit 0) else (exit 1)')


def cekajinternet():
    if (internetprovera()):
        return
    else:
        print('cekam internet!')

    while(1):
        if (internetprovera()):
            return
        else:
            time.sleep(1)

def granicnik():
    print(f'{zuta2}----------------------------------------------------------------------{normalna}')
def intro():
    s = '''
 _               _     _____                                               
| |             | |   |  __ \                                              
| |     ___  ___| |__ | |__) | __ ___   __ _ _ __ __ _ _ __ ___   ___ _ __ 
| |    / _ \/ __| '_ \|  ___/ '__/ _ \ / _` | '__/ _` | '_ ` _ \ / _ \ '__|
| |___| (_) \__ \ | | | |   | | | (_) | (_| | | | (_| | | | | | |  __/ |   
|______\___/|___/_| |_|_|   |_|  \___/ \__, |_|  \__,_|_| |_| |_|\___|_|   
                                        __/ |                              
                                       |___/                               
 > LoshV0.1
 > https://github.com/loshprogramer\n'''
    granicnik()   
    print(normalna+s+resetuj)
    granicnik()

def numOfDays(date1, date2):
    return (date2 - date1).days

def bojaf(dani):
    if ( dani <= 0 ):
        boja = crvena
    elif ( dani == 1 or dani == 2 ):
        boja = zuta
    elif ( 2 < dani <= 7 ):
        boja = zelena
    elif ( 7 < dani <= 30 ):
        boja = plava
    elif ( 30 < dani <= 90 ):
        boja = bela
    else: 
        boja = normalna
    return boja

def bojaHtml(dani):
    if ( dani <= 0 ):
        boja = 'red'
    elif ( dani == 1 or dani == 2 ):
        boja = 'yellow'
    elif ( 2 < dani <= 7 ):
        boja = 'green'
    elif ( 7 < dani <= 30 ):
        boja = 'blue'
    elif ( 30 < dani <= 90 ):
        boja = 'gray'
    else: 
        boja = 'white'
    return boja


def ucitaj(ime):
    fajl = open(ime, "r", encoding='utf-8')
    data = fajl.read()
    fajl.close()
    return data

def upisifajl(ime, linija, kako):
    f = open(ime, kako, encoding='utf-8')
    f.write(linija + "\n")
    f.close()
    
def upisibazu(id, napravljen):
    f = open('baza-svih-kanala.txt', 'a', encoding='utf-8')
    f.write(id +"|"+napravljen+"\n" )
    f.close()

def duplikati(fajl):
    if ( os.path.isfile(fajl) ):    
        file = ucitaj(fajl)
        x = file.split("\n")
        
        while("" in x) :
            x.remove("")
        y = list(dict.fromkeys(x))
        
        f = open(fajl, 'w', encoding='utf-8')
        for i in range(len(y)):
            f.write(y[i] + "\n")
        f.close()

def ucitajBazu():
    nizid = []
    niznapravljen = []

    if ( os.path.isfile('baza-svih-kanala.txt') ):
        file = ucitaj('baza-svih-kanala.txt')
        x = file.split("\n")
    
        for i in range(len(x) -1 ):
            nizid.append(x[i].split("|")[0])
            niznapravljen.append(x[i].split("|")[1])
    else: 
        print(f"Nema baza-svih-kanala.txt!")
    return nizid, niznapravljen

def ucitajPouzdane():
    pouzdani = []

    if ( os.path.isfile('pouzdani-kanali.txt') ):
        file = ucitaj('pouzdani-kanali.txt')
        x = file.split("\n")
    
        for i in range(len(x) -1 ):
            pouzdani.append(x[i].lstrip().split(" ")[0])
    else: 
        print(f"Nema pouzdani-kanali.txt!")
    return pouzdani

def preuzmi(sajt, verifikacija):
    try:
        r = requests.get(sajt, verify=verifikacija, headers={
            'Accept-Charset' : 'utf-8', 
            'Accept-Language' : 'en-US,en;q=0.9,it;q=0.8', 
            'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4863.0 Safari/537.36' 
        })
    except:
        upisifajl('TEMP\\izvestaj-o-greskama.txt','\n'+str(datetime.now())+' = funkcija preuzmi greska','a+')
        traceback.print_exc(file=open('TEMP\\izvestaj-o-greskama.txt','a+'))
        return -1

    if (r.status_code == 200):
        return r.text
    else:
        return r.status_code


    
def iscupajDatum(sadrzaj):
    s1 = '"Joined "},{"text":"'
    s2 = '"}]},"'

    poz1 = sadrzaj.find(s1)
    if (poz1 == -1):
        return -1

    poz2 = sadrzaj.find(s2, poz1)
    if (poz2 == -1):
        return -1
    
    return sadrzaj[poz1+20:poz2]

def iscupajDatumKlipa(sadrzaj):
    s1 = '"dateText":{"simpleText":"'
    s2 = '"}}},'

    poz1 = sadrzaj.find(s1)
    if (poz1 == -1):
        return -1

    poz2 = sadrzaj.find(s2, poz1)
    if (poz2 == -1):
        return -1
    
    return sadrzaj[poz1+26:poz2]

def iseciVreme(vreme):
    return vreme[11:19]

def konvertujVreme(timestamp):
    return (str(datetime.fromtimestamp(int(timestamp))))


def brojDana(napravljen):
    global utczona
    joindate = datetime.strptime(napravljen, '%b %d, %Y') 
    trenutno = datetime.now() + timedelta(hours=utczona) - timedelta(days=korekcija)
    return (numOfDays (date(joindate.year,joindate.month,joindate.day), date(trenutno.year,trenutno.month,trenutno.day)))

def iscupajNaslov(videoid):

    sadrzaj = preuzmi(f'https://www.youtube.com/watch?v={videoid}',True)

    if(isinstance(sadrzaj, int)):
        upisifajl('TEMP\\izvestaj-o-greskama.txt','\n'+str(datetime.now())+' = funkcija iscupajNaslov greska preuzimanja naslova','a+')
        return 'greska preuzimanja naslova [youtube odbio konekciju ili VPN]'

    s1 = '<meta name="title" content="'
    s2 = '">'

    poz1 = sadrzaj.find(s1)
    if (poz1 == -1):
        return -1

    poz2 = sadrzaj.find(s2, poz1)
    if (poz2 == -1):
        return -1
    
    return sadrzaj[poz1+len(s1):poz2]

def lajv(videoid):
    kod = preuzmi(f'https://www.youtube.com/watch?v={videoid}',True)

    if(isinstance(kod, int)):
        print('greska preuzimanja lajv statusa [youtube odbio konekciju ili VPN]')
        upisifajl('TEMP\\izvestaj-o-greskama.txt','\n'+str(datetime.now())+' = funkcija lajv greska preuzimanja lajv statusa','a+')

        return 1
    #if error return true

    s1 = '"isLive":true'
 
    if s1 in kod:
        return 1
    else:
        return 0

#======================TABELE=HTML================================
def htmlUvod(fajl):
    uvod = '''
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>'''+naslov+'''</title>

<script>
function scrollWin() {
  window.scrollTo(0,document.body.scrollHeight);
}


if (window.location.search.startsWith('?osvezi'))
{

var intervalId = window.setInterval(function(){
scrollWin();
clearInterval(intervalId) 
}, 300);

var r = Number(window.location.search.slice(8))
var rs = 1000 * r

document.title = r.toString(10)+ ' sec - osvezi';

window.setTimeout( function() {
  window.location.reload();
}, rs);

}
</script>

</head>

<body style = "background-color: white;">
<center>
<h1>'''+naslov+'''</h1>
<a href="?osvezi=5" style="color:red;"><h3>[ukljuci osvezavanje na 5 sekundi]</h3></a>
</center>
    <table width="100%" style="border-spacing: 1px;table-layout: fixed;margin-left: auto;margin-right: auto;">
<tr>
<th width="1%" style="color: green;border: 1px solid black;text-align: center;">></th>
<th width="10%" style="color: green;border: 1px solid black;text-align: center;">VREME</th>
<th width="21%" style="color: green;border: 1px solid black;text-align: center;">KANAL</th>
<th width="60%" style="color: green;border: 1px solid black;text-align: center;">PORUKA</th>
<th width="8%" style="color: green;border: 1px solid black;text-align: center;">STAR</th>
</tr>

'''
    upisifajl(fajl,uvod,'w')

def tabelaJedna(fajl, tekst, boja=None):
    if boja is None:
        s1 = '<td style="border: 1px solid gray;word-break: break-all;text-align: left;">'
    else:
        s1 = '<td style="background-color: '+boja+';border: 1px solid gray;word-break: break-all;text-align: left;">'

    s2 = '</td>'
    upisifajl(fajl,s1+tekst+s2,'a')

#=================================================================

def link(uri, label=None):
    if label is None: 
        label = uri
    parameters = ''

    # OSC 8 ; params ; URI ST <name> OSC 8 ;; ST 
    escape_mask = '\033]8;{};{}\033\\{}\033]8;;\033\\'

    return escape_mask.format(parameters, uri, label)

def stampaj(hesiran, pouzdan, videoid, id, vreme, ime, poruka, napravljen, brojdana):

    global kodz

    fajl = 'ISTORIJA\\'+videoid+'.html'
    boja = bojaf(brojdana)
    boja2 = bojaHtml(brojdana)

    blinkajStrelica = ''

    if (pouzdan == 1):
        hashBoja = plava
        hashHtml = 'blue'
    else:

        if (hesiran == 1):
            hashBoja = zelena2
            hashHtml = 'green'

        elif(brojdana <= 30):
            blinkaj()
            if (kodz == 1):
                print('\a', end ="")
            hashBoja = crvena
            blinkajStrelica = f'{normalna} {crvena}<---PRVI PUT'
            hashHtml = 'red'

        else:
            hashBoja = crvena2
            hashHtml = 'red'


    imelink = link(f'https://www.youtube.com/channel/{id}/about', ime)
    print(f'{hashBoja}>{normalna}{vreme} {boja}[{imelink}] [{brojdana} DANA = {napravljen}] ---> {emoji.emojize(poruka, language="alias")}{blinkajStrelica}{normalna}|')

    upisifajl(fajl,f'<tr style="background-color: {boja2};">','a')
    tabelaJedna(fajl, '>', hashHtml)
    tabelaJedna(fajl, f'{vreme}')
    tabelaJedna(fajl, f'<a href="https://www.youtube.com/channel/{id}/about" style="color:black;" target="_blank">{ime}</a>')
    
    tabelaJedna(fajl, emoji.emojize(poruka, language="alias"))
    tabelaJedna(fajl, f'{str(brojdana)} d')
    upisifajl(fajl,'</tr>','a')


def istorijaProvera(videoid):
    if not ( os.path.isfile(f'ISTORIJA\\{videoid}.html') ):
        htmlUvod(f'ISTORIJA\\{videoid}.html')

def ucitajNizove():
    duplikati('baza-svih-kanala.txt')
    global nizid, niznapravljen
    nizid, niznapravljen = ucitajBazu()

    duplikati('pouzdani-kanali.txt')
    global pouzdani
    pouzdani = ucitajPouzdane()


def motorPrograma(videoid, id, vreme, ime, poruka):

    if ( id ) in pouzdani:
        pouzdan = 1
    else:
        pouzdan = 0


    if ( id ) not in nizid:
        sadrzaj = preuzmi(f'https://www.youtube.com/channel/{id}/about', True)

        if(isinstance(sadrzaj, int)):
            print('greska preuzimanja kanala [youtube odbio konekciju ili VPN]')
            upisifajl('TEMP\\izvestaj-o-greskama.txt','\n'+str(datetime.now())+' = funkcija motorPrograma greska preuzimanja kanala','a+')
            return

        try:
            napravljen = iscupajDatum(sadrzaj)
            brojdana = brojDana(napravljen)
        except:
            print('neispravan format datuma')
            upisifajl('TEMP\\izvestaj-o-greskama.txt','\n'+str(datetime.now())+' = funkcija motorPrograma neispravan format datuma','a+')
            traceback.print_exc(file=open('TEMP\\izvestaj-o-greskama.txt','a+'))
            return

        #OVDE NE SME DA DODJE INACE ODE BAZA
        nizid.append(id)
        niznapravljen.append(napravljen)
        upisibazu(id, napravljen) 
        stampaj(0, pouzdan ,videoid, id, vreme, ime, poruka, napravljen, brojdana)

    else:
        pozicija = nizid.index(id)
        brojdana = brojDana(niznapravljen[pozicija])
        stampaj(1, pouzdan, videoid, id, vreme, ime, poruka, niznapravljen[pozicija], brojdana)


def parser1(videoid):
#Chat-Downloader parser
    url = f'https://www.youtube.com/watch?v={videoid}'
    chat = chat_downloader.ChatDownloader().get_chat(url, message_groups=['messages', 'superchat'])       
    for message in chat:                       

        ime = message['author']['name']
        id = message['author']['id']
        poruka = message['message']
        vreme = iseciVreme(konvertujVreme(message['timestamp']/1000000))

        if not (isinstance(poruka, str)):
            poruka = 'NO-MESSAGE'

        if not (isinstance(ime, str)):
            poruka = 'NO-NAME'
        
        motorPrograma(videoid, id, vreme, ime, poruka)

def parser2(videoid):
#Pytchat parser
    chat = pytchat.create(video_id=videoid)
    while chat.is_alive():
        for c in chat.get().sync_items():

            ime = c.author.name
            id = c.author.channelId
            poruka = c.message
            vreme = iseciVreme(c.datetime)

            motorPrograma(videoid, id, vreme, ime, poruka)


def otvoriGUI(id_snimka):
    
    granicnik()
    print('[1] Edge')
    print('[2] Chrome')
    print('[3] Opera')
    print('[4] Firefox')
    print('[5] Brave')
    print('[6] SAMO KONZOLA\n')
    kodp = os.system('choice /c 123456 /m "Izaberi pretrazivac:"')
    granicnik()
    if (kodp == 1):
        pretrazivac = 'msedge'
    elif (kodp == 2):
        pretrazivac = 'chrome'
    elif (kodp == 3):
        pretrazivac = 'opera'
    elif (kodp == 4):
        pretrazivac = 'firefox'
    elif (kodp == 5):
        pretrazivac = 'brave'

    if (kodp != 6):
        os.system(f'start "" {pretrazivac} /new-window "https://www.youtube.com/live_chat?is_popout=1&v={id_snimka}"')
        time.sleep(3)
        os.system(f'start "" {pretrazivac} "%CD%\\ISTORIJA\\{id_snimka}.html"')

def funKorekcija(id_snimka):
    global korekcija

    if (lajv(id_snimka)):
        print(f'{zelena2} > {naslov} [UZIVO SAD]{normalna}')
        granicnik()
    else:
        print(f'{crvena2} > {naslov} [NIJE VISE UZIVO]{normalna}')

        try:
            sadrzaj = preuzmi(f'https://youtube.com/watch?v={id_snimka}', True)

            if(isinstance(sadrzaj, int)):
                print('greska preuzimanja video datuma [youtube odbio konekciju ili VPN]')
                upisifajl('TEMP\\izvestaj-o-greskama.txt','\n'+str(datetime.now())+' = funkcija Korekcija greska preuzimanja video datuma','a+')
                snimano = 'error'
                raise Exception

            snimano = iscupajDatumKlipa(sadrzaj)
            korekcija = brojDana(snimano[17:])
            
            print(f'{crvena2} > pre {korekcija} dana{normalna}') 
            granicnik()

        except:
            print(f'{crvena2} > Ne mogu da ucitam ovo kao datum: {zuta2}[{snimano}]{normalna}')
            upisifajl('TEMP\\izvestaj-o-greskama.txt','\n'+str(datetime.now())+' = funkcija Korekcija neispravan format datuma','a+')
            traceback.print_exc(file=open('TEMP\\izvestaj-o-greskama.txt','a+'))
            korekcija = int(input(f'{crvena2} > Unesi rucno pre koliko dana je bio ovaj strim:{normalna} '))
            granicnik()



def proveraNadogradnje():
    sadrzaj = preuzmi('https://raw.githubusercontent.com/loshprogramer/losh/main/verzija', False)

    if(isinstance(sadrzaj, int)):
        return

    x = sadrzaj.split("\n")

    if (x[0] != 'verzija'):
        return

    if (x[1] != 'v0.1'):
        os.system(f'title IMA NOVA VERZIJA {x[1]}')


#==================----------=============-------------===============----------------==================
os.system('cls')
if (len(sys.argv) == 1):
    sys.exit(-1)
threading.Thread(target=proveraNadogradnje).start()
ucitajNizove()
os.system("IF NOT EXIST ISTORIJA (MD ISTORIJA)")
os.system("IF NOT EXIST TEMP (MD TEMP)")
#==================----------=============-------------===============----------------==================

if(sys.argv[1] == 'normalno'):
    cekajinternet()
    intro()
    korekcija = 0
    #utczona = int(input(f'{zuta2} > Unesi vremensku zonu UTC+[-12,12]: {normalna}'))
    #za nas je utc+1
    utczona = 1
    #granicnik()
    utczona = -8 - utczona
    # utc-8 yt time for en
    upisifajl('TEMP\\poslednji-strim.tmp',str(utczona),'w')

    id_snimka = input(f'{zuta2} > Unesi ID: {normalna}')
    upisifajl('TEMP\\poslednji-strim.tmp',id_snimka,'a')
    cekajinternet()
    naslov = iscupajNaslov(id_snimka)

    funKorekcija(id_snimka)

    upisifajl('TEMP\\poslednji-strim.tmp',str(korekcija),'a')

    print('[1] Da\n[2] Ne\n\a')
    kodz = os.system('choice /c 12 /m "Ukljuci ovakvo zvucno obavestenje za kanale koji se prvi put pojavljuju do sad a mladji su od 30 dana:"')
    granicnik()
    upisifajl('TEMP\\poslednji-strim.tmp',str(kodz),'a')

    print('[1] chat-downloader [svi strimovi i uzivo i prosli]\n[2] pytchat [samo strimovi uzivo]\n')
    kod = os.system('choice /c 12 /m "Odaberi parser:"')
    upisifajl('TEMP\\poslednji-strim.tmp',str(kod),'a')

    upisifajl('TEMP\\poslednji-strim.tmp',naslov,'a')

    istorijaProvera(id_snimka)
    otvoriGUI(id_snimka)
    

if(sys.argv[1] == 'ponovo'):
    cekajinternet()
    prosliString = ucitaj('TEMP\\poslednji-strim.tmp')
    x = prosliString.split("\n")
    utczona = int(x[0])
    id_snimka = x[1]
    korekcija = int(x[2])
    kodz = int(x[3])
    kod = int(x[4])
    naslov = x[5]
    granicnik()

    upisifajl('TEMP\\izvestaj-o-greskama.txt','\n'+str(datetime.now())+' = POKRECEM PONOVO','a+')


print(f'{zuta2}{naslov} | cekam na poruke ...\n{normalna}')
cekajinternet()


if (kod == 1):
    try:
        upisifajl('TEMP\\izvestaj-o-greskama.txt','\n'+str(datetime.now())+' = [chat-downloader start]','a+')
        parser1(id_snimka)
    except:
        print(f'{crvena2} > chat-downloader idle mode{normalna}')
        upisifajl('TEMP\\izvestaj-o-greskama.txt','\n'+str(datetime.now())+' = [chat-downloader exit]','a+')
        traceback.print_exc(file=open('TEMP\\izvestaj-o-greskama.txt','a+'))
else: 
    try:
        upisifajl('TEMP\\izvestaj-o-greskama.txt','\n'+str(datetime.now())+' = [pytchat start]','a+')
        parser2(id_snimka)
    except:
        print(f'{crvena2} > pytchat idle mode{normalna}')
        upisifajl('TEMP\\izvestaj-o-greskama.txt','\n'+str(datetime.now())+' = [pytchat exit]','a+')
        traceback.print_exc(file=open('TEMP\\izvestaj-o-greskama.txt','a+'))

cekajinternet()
if (lajv(id_snimka)):
    print(f'{crvena2}{naslov} -> [I DALJE UZIVO POKRECEM PONOVO]{normalna}')
    sys.exit(123)
else:
    print(f'{zelena2}{naslov} -> [NIJE VISE UZIVO]{normalna}')
    granicnik()
    while (1):
        os.system('pause > nul')



